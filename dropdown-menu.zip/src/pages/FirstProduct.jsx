function FirstProduct() {
  return (
    <div className="h-[450px] text-3xl text-bold text-center bg-[#eee]">
      FirstProduct
    </div>
  );
}

export default FirstProduct;
