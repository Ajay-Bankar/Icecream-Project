function SecondProduct() {
  return (
    <div className="h-[450px] text-3xl text-bold text-center bg-[#eee]">
      SecondProduct
    </div>
  );
}

export default SecondProduct;
