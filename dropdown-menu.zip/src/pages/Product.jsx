function Product() {
  return (
    <div className="h-[450px] text-3xl text-bold text-center bg-[#eee]">
      Product
    </div>
  );
}

export default Product;
