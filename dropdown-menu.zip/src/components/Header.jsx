import { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { IoMenuSharp, IoClose } from "react-icons/io5";

const navData = [
  { title: "Home", linkTo: "/" },
  { title: "About Us", linkTo: "about" },
  {
    title: "Product",
    subMenu: [
      { title: "Product", linkTo: "product" },
      { title: "First Product", linkTo: "product/first_product" },
      { title: "Second Product", linkTo: "product/second_product" },
    ],
  },
  { title: "Contact Us", linkTo: "contact" },
];
const Header = () => {
  const [open, setOpen] = useState(false);
  const [subMenuOpen, setSubMenuOpen] = useState(false);
  return (
    <div className="bg-red-600 text-white ">
      <div className="w-11/12 mx-auto ">
        <div className="sm:hidden mx-2 py-2 flex justify-between items-center">
          <div
            className="text-2xl text-primary  cursor-pointer"
            onClick={() => setOpen(!open)}
          >
            {open ? <IoClose /> : <IoMenuSharp />}
          </div>
        </div>

        <div
          className={`flex sm:flex-row mt-5 sm:mt-0 flex-col ${
            open ? `block` : `hidden sm:flex`
          }  sm:gap-x-7 2xl:gap-x-8`}
        >
          {navData.map((menuItem, index) => (
            <button
              key={index}
              className=" text-left text-base sm:text-xl relative py-1 sm:py-4"
            >
              {menuItem.linkTo ? (
                <NavLink
                  to={menuItem.linkTo}
                  onClick={() => {
                    setOpen(!open), setSubMenuOpen(false);
                  }}
                  className="link-underline-white  font-semibold  text-primary hover:text-secondary"
                >
                  {menuItem.title}
                </NavLink>
              ) : (
                <>
                  <a
                    onClick={() => {
                      setSubMenuOpen(!subMenuOpen);
                    }}
                    className="flex cursor-pointer items-center text-base sm:text-xl justify-between py-2  text-white  font-semibold group-hover:text-white lg:mr-0 lg:inline-flex lg:py-0 lg:px-0"
                  >
                    {menuItem.title}
                    <span className="pl-1 mt-1">
                      <svg
                        width="15"
                        height="14"
                        viewBox="0 0 15 14"
                        className={`${subMenuOpen ? "rotate-180" : ""} `}
                      >
                        <path
                          d="M7.81602 9.97495C7.68477 9.97495 7.57539 9.9312 7.46602 9.8437L2.43477 4.89995C2.23789 4.70308 2.23789 4.39683 2.43477 4.19995C2.63164 4.00308 2.93789 4.00308 3.13477 4.19995L7.81602 8.77183L12.4973 4.1562C12.6941 3.95933 13.0004 3.95933 13.1973 4.1562C13.3941 4.35308 13.3941 4.65933 13.1973 4.8562L8.16601 9.79995C8.05664 9.90933 7.94727 9.97495 7.81602 9.97495Z"
                          fill="currentColor"
                        />
                      </svg>
                    </span>
                  </a>
                  {subMenuOpen && menuItem.subMenu && (
                    <div
                      className={`relative pt-0 sm:pt-3 top-full left-0  ${
                        subMenuOpen ? "opacity-100 lg:visible z-50" : ""
                      }    lg:absolute lg:top-[90%] lg:block lg:w-[200px]  lg:opacity-100 lg:shadow-lg lg:group-hover:visible lg:group-hover:top-full z-[99]`}
                    >
                      {menuItem.subMenu.map((submenuItem, index) => (
                        <Link
                          to={submenuItem.linkTo}
                          onClick={() => {
                            setSubMenuOpen(!subMenuOpen), setOpen(!open);
                          }}
                          key={index}
                          className="block py-2.5 text-left text-white sm:text-black hover:text-red-600 text-sm sm:text-base  hover:opacity-90 px-2"
                        >
                          {submenuItem.title}
                        </Link>
                      ))}
                    </div>
                  )}
                </>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Header;
