const Footer = () => {
  return (
    <div className="bg-red-600 text-white h-20">
      <h2 className="text-2xl font-bold text-center">Footer</h2>
    </div>
  );
};

export default Footer;
